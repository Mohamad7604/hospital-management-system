<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'patient') {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Patient Dashboard</title>
</head>
<body>
    <h2>Welcome, <?php echo $_SESSION['user_name']; ?>!</h2>
    <ul>
        <li><a href="book_appointment.php">Book Appointment</a></li>
        <li><a href="view_appointments.php">View Appointments</a></li>
        <li><a href="billing.php">View Bills</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</body>
</html>
