<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'doctor') {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Doctor Dashboard</title>
</head>
<body>
    <h2>Welcome, Dr. <?php echo $_SESSION['user_name']; ?>!</h2>
    <ul>
        <li><a href="view_appointments.php">View Appointments</a></li>
        <li><a href="prescribe_medications.php">Prescribe Medications</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</body>
</html>
